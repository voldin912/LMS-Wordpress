<?php
/**
 * PHPUnit bootstrap file.
 *
 * @package Learndash_Woocommerce
 */

if ( PHP_MAJOR_VERSION >= 8 ) {
	echo "The scaffolded tests cannot currently be run on PHP 8.0+. See https://github.com/wp-cli/scaffold-command/issues/285" . PHP_EOL; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	exit( 1 );
}

$_tests_dir = getenv( 'WP_TESTS_DIR' );

if ( ! $_tests_dir ) {
	$_tests_dir = rtrim( sys_get_temp_dir(), '/\\' ) . '/wordpress-tests-lib';
}

if ( ! file_exists( "{$_tests_dir}/includes/functions.php" ) ) {
	echo "Could not find {$_tests_dir}/includes/functions.php, have you run bin/install-wp-tests.sh ?" . PHP_EOL; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	exit( 1 );
}

// Set globals
$active_plugins = [
	'learndash-woocommerce/learndash_woocommerce.php',
	'sfwd-lms/sfwd_lms.php',
	'woocommerce/woocommerce.php',
];

$GLOBALS['wp_tests_options'] = [
	'active_plugins' => $active_plugins
];

// Give access to tests_add_filter() function.
require_once "{$_tests_dir}/includes/functions.php";

/**
 * Manually load the plugin being tested.
 */
function _manually_load_plugin() {
	require dirname( dirname( __FILE__ ) ) . '/learndash_woocommerce.php';

	define( 'LEARNDASH_LMS_PLUGIN_DIR', dirname( dirname( dirname( __FILE__ ) ) ) . '/sfwd-lms/' );
	define( 'LEARNDASH_FILE', dirname( dirname( dirname( __FILE__ ) ) ) . '/sfwd-lms/sfwd_lms.php' );
	require dirname( dirname( dirname( __FILE__ ) ) ) . '/sfwd-lms/sfwd_lms.php';
	
	require dirname( dirname( dirname( __FILE__ ) ) ) . '/woocommerce/woocommerce.php';
}

tests_add_filter( 'muplugins_loaded', '_manually_load_plugin' );

tests_add_filter( 'init', function() {
	// Create LearnDash DB tables.
	$ld_admin_settings_data_upgrades_db = Learndash_Admin_Data_Upgrades::get_instance( 'Learndash_Admin_Data_Upgrades_User_Activity_DB_Table' );
	$ld_admin_settings_data_upgrades_db->upgrade_db_tables();

	// Create WooCommerce DB tables.
	WC_Install::install();
});

// Start up the WP testing environment.
require "{$_tests_dir}/includes/bootstrap.php";
