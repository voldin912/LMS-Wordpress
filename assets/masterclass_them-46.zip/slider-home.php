
<style>
    
</style>

<section class="sec2-slide">
            <div class="container">
            <div class="wrapper">
                <div class="next">Next</div>
                <div class="prev">Prev</div>
                <div class="buttons">
                    <button class="go" data-index="0">Go to A</button><br/><br/>
                    <button class="go" data-index="1">Go to B</button><br/><br/>
                    <button class="go" data-index="2">Go to C</button><br/><br/>
                    <button class="go" data-index="3">Go to D</button><br/><br/>
                    <button class="go" data-index="4">Go to E</button>
                </div>
                <div class="duration-container">
                    <div class="duration">
                    </div>
                </div>
                <div class="content">
                    <div class="scroll-container">
                    <div id="carousel" class="carousel"><div class="active front">A</div><div class="below">B</div><div>C</div><div>D</div><div>E</div>
                    </div>
                    </div> 
                </div>
                </div>
            </div>
</section>

<script>

</script>